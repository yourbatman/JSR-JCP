These files together comprise the binaries for the Reference Implementation (RI) for JSR 173 (Streaming API for XML Specification),
including its API classes and interfaces.


The following lists the files in this distribution:

README-BIN.txt               [README file for the binaries of the Reference Implementation JSR 173 bundle.]

ASF2.0.txt                   [Apache Software Foundation License 2.0]
lib/jsr173_1.3_ri.jar        [The class files for the reference implementation-RI ]
lib/jsr173_1.3_api.jar       [The class files for the API ]
lib/dtdparser.jar            [DTD parser needed for the Reference Implementation-RI]
lib/jax-qname.jar            [Needed by RI]
lib/namespace.jar            [Needed by RI]

Your right to use the listed files, whether together or individually, is governed by the Apache Software Foundation License 2.0 included in this bundle.

Please see the javadoc for information on how to get started.

